#' titanic: Titanic Passenger Survival Data Set
#'
#' @docType package
#' @name titanic
NULL
